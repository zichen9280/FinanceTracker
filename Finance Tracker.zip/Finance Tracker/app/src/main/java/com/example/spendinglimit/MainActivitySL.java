package com.example.spendinglimit;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivitySL extends AppCompatActivity {

    private FloatingActionButton fab;
    DataStorage db;
    RecyclerView recyclerView;
    ArrayList<String> category_id, category_daymonth,category_name, category_amount;
    RecyclerAdapter recyclerAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_sl);
        recyclerView = findViewById(R.id.recyclerView);

        fab = findViewById(R.id.fab);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivitySL.this, AddLimit.class);
                startActivity(intent);
            }
        });

        db = new DataStorage(MainActivitySL.this);
        category_id = new ArrayList<>();
        category_daymonth = new ArrayList<>();
        category_name = new ArrayList<>();
        category_amount = new ArrayList<>();


        showdata();

        recyclerAdapter = new RecyclerAdapter(MainActivitySL.this, category_daymonth ,category_id, category_name, category_amount);
        recyclerView.setAdapter(recyclerAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivitySL.this));
    }

    void showdata() {
        Cursor cursor = db.readAllDataSL();
        if (cursor.getCount() == 0) {
            Toast.makeText(this, "There is no data to show", Toast.LENGTH_SHORT).show();
        } else {
            while (cursor.moveToNext()) {
                category_id.add(cursor.getString(0));
                category_daymonth.add(cursor.getString(1));
                category_name.add(cursor.getString(2));
                category_amount.add(cursor.getString(3));
            }
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.limit_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.delete_all){
            confirmDialog();
        }
        return super.onOptionsItemSelected(item);
    }

    void confirmDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete All?");
        builder.setMessage("Are you sure you want to delete all Data?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                DataStorage myDB = new DataStorage(MainActivitySL.this);
                myDB.deleteAllDataSL();
                //Refresh Activity
                Intent intent = new Intent(MainActivitySL.this, MainActivitySL.class);
                startActivity(intent);
                finish();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create().show();
    }

}