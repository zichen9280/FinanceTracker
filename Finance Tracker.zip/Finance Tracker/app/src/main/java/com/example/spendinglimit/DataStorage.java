package com.example.spendinglimit;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class DataStorage extends SQLiteOpenHelper {
    private Context context;
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "spendinglimit";

    private static final String MYDATABASE_TABLE_4 = "user_data";
    private static final String COL_ID = "_id";
    private static final String COL_NAME = "categories";
    private static final String COL_DAYMONTH = "daymonth";
    private static final String COL_LIMIT = "amount";


    DataStorage(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + MYDATABASE_TABLE_4 +
                " (" + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_DAYMONTH + " TEXT, " +
                COL_NAME + " TEXT, " +
                COL_LIMIT + " TEXT);";
        db.execSQL(query);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + MYDATABASE_TABLE_4);
        onCreate(db);
    }

    void add_amountSL(String daymonth, String name, String amount){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COL_DAYMONTH, daymonth);
        cv.put(COL_NAME, name);
        cv.put(COL_LIMIT, amount);
        long result = db.insert(MYDATABASE_TABLE_4,null, cv);
        if(result == -1){
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(context, "Added Successfully!", Toast.LENGTH_SHORT).show();
        }
    }

    Cursor readAllDataSL(){
        String query = "SELECT * FROM " + MYDATABASE_TABLE_4;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = null;
        if(db != null){
            cursor = db.rawQuery(query, null);
        }
        return cursor;
    }

    void updateDataSL(String limit_id, String daymonth, String name, String amount){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_DAYMONTH, daymonth);
        cv.put(COL_NAME, name);
        cv.put(COL_LIMIT, amount);


        long result = db.update(MYDATABASE_TABLE_4, cv, "_id=?", new String[]{limit_id});
        if(result == -1){
            Toast.makeText(context, "Please try again.", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(context, "Update Success. Returning to previous page.", Toast.LENGTH_SHORT).show();
        }

    }

    void deleteAnSpendingLimit(String limit_id){
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(MYDATABASE_TABLE_4, "_id=?", new String[]{limit_id});
        if(result == -1){
            Toast.makeText(context, "Please try again.", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(context, "Remove Success. Returning to previous page.", Toast.LENGTH_SHORT).show();
        }
    }

    void deleteAllDataSL(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + MYDATABASE_TABLE_4);
    }

}

