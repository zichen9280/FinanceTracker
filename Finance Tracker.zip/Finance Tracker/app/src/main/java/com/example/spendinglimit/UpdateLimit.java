package com.example.spendinglimit;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class UpdateLimit extends AppCompatActivity {

    EditText name_input, amount_input;
    Button update_account, delete_account;
    Spinner daymonth_input;
    String no, category, amount, daymonth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_limit);
        Spinner spinner_edit = findViewById(R.id.spinner_edit);
        daymonth_input = findViewById(R.id.spinner_edit);
        name_input = findViewById(R.id.category_txt);
        amount_input = findViewById(R.id.amount_txt);
        update_account = findViewById(R.id.update_txt);
        delete_account = findViewById(R.id.delete_txt);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.daymonth, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_edit.setAdapter(adapter);
        getAndSetIntentData();
        update_account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DataStorage passdb = new DataStorage(UpdateLimit.this);
                daymonth = daymonth_input.getSelectedItem().toString();
                category = name_input.getText().toString().trim();
                amount = amount_input.getText().toString().trim();
                passdb.updateDataSL(no, daymonth ,category, amount);
                finishActivity();
            }
        });
        delete_account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmDialog();
            }
        });
    }

    void getAndSetIntentData() {
        if (getIntent().hasExtra("no") && getIntent().hasExtra("category")
                && getIntent().hasExtra("daymonth") && getIntent().hasExtra("amount")) {

            no = getIntent().getStringExtra("no");
            daymonth = getIntent().getStringExtra("daymonth");
            category = getIntent().getStringExtra("category");
            amount = getIntent().getStringExtra("amount");
            name_input.setText(category);
            amount_input.setText(amount);

        } else {
            Toast.makeText(this, "No data.", Toast.LENGTH_SHORT).show();
        }
    }

    private void finishActivity() {
        Intent intent = new Intent(this, MainActivitySL.class);
        startActivity(intent);
    }

    void confirmDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete account of " + category );
        builder.setMessage("Are you sure you want to delete " + category + " ?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                DataStorage myDB = new DataStorage(UpdateLimit.this);
                myDB.deleteAnSpendingLimit(no);
                finish();
                finishActivity();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create().show();
    }
}