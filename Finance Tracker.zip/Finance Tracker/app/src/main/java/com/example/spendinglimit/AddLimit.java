package com.example.spendinglimit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class AddLimit extends AppCompatActivity{

    EditText category_input, amount_input;
    Button insert_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_limit);


        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.daymonth, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        Spinner spinner = findViewById(R.id.spinner);
        spinner.setAdapter(adapter);
        category_input = findViewById(R.id.category);
        amount_input = findViewById(R.id.amount);

        insert_button = findViewById(R.id.insert_button);

        insert_button.setOnClickListener(view -> {
            DataStorage myPasswordStorage = new DataStorage(AddLimit.this);
            if(!spinner.getSelectedItem().equals("Select Daily, Weekly or Monthly")){
            myPasswordStorage.add_amountSL(spinner.getSelectedItem().toString(), category_input.getText().toString().trim(),
                    amount_input.getText().toString().trim());
            finishActivity();
            } else {
                Toast.makeText(this, "Select a valid option", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void finishActivity() {
        Intent intent = new Intent(this, MainActivitySL.class);
        startActivity(intent);
    }

}