package com.example.spendinglimit;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.content.res.TypedArrayUtils;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.MyViewHolder> {

    private Context context;

    private ArrayList category_id, category_daymonth, category_name,  category_amount;

    RecyclerAdapter(Context context,  ArrayList category_daymonth,ArrayList category_id, ArrayList category_name, ArrayList category_amount){

        this.context = context;
        this.category_id = category_id;
        this.category_daymonth = category_daymonth;
        this.category_name = category_name;
        this.category_amount = category_amount;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.data_row, parent, false);
        return new MyViewHolder(view);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {
        holder.application_id_txt.setText(String.valueOf(category_id.get(position)));
        holder.daymonth_txt.setText(String.valueOf(category_daymonth.get(position)));
        holder.category_txt.setText(String.valueOf(category_name.get(position)));
        holder.amount_txt.setText(String.valueOf(category_amount.get(position)));

        holder.mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context , UpdateLimit.class);
                intent.putExtra("no", String.valueOf(category_id.get(position)));
                intent.putExtra("daymonth", String.valueOf(category_daymonth.get(position)));
                intent.putExtra("category", String.valueOf(category_name.get(position)));
                intent.putExtra("amount", String.valueOf(category_amount.get(position)));
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return category_id.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {

        TextView application_id_txt , category_txt,  amount_txt, daymonth_txt;

        LinearLayout mainLayout;

        MyViewHolder(@NonNull View itemView) {
            super(itemView);
            application_id_txt = itemView.findViewById(R.id.category_id_txt);
            daymonth_txt = itemView.findViewById(R.id.daymonth_txt);
            category_txt = itemView.findViewById(R.id.category_txt);
            amount_txt = itemView.findViewById(R.id.amount_txt);
            mainLayout = itemView.findViewById(R.id.dataLayout);
        }

    }

}
